Run the emulation with:

  qemu-system-nios2 -kernel output/images/vmlinux -nographic

The login prompt will appear in the terminal that started Qemu.

Tested with QEMU 2.9.0.
